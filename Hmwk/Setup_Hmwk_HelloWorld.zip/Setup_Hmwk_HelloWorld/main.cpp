/* 
 * File:   Setup_Hmwk_Helloworld
 * Author: Jose Lopez
 * Created on January 7, 2015, 10:54 PM
 * Purpose: For setup of Github account thingy.
 */

//System Library
#include <iostream>
using namespace std;

//User Library

//Global Constant

//Functioning Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    cout<<"Hello World"<<endl;
    return 0;
}

